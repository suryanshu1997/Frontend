import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-medicine',
  templateUrl: './search-medicine.component.html',
  styleUrls: ['./search-medicine.component.css']
})
export class SearchMedicineComponent implements OnInit {

  medicine :string;
  result: string;
  
  constructor() { }

  ngOnInit() {
  }
  onChange(val)
  {
    console.log(val);
    this.result = val;
  }
}
