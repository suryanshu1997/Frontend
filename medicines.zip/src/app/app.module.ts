import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import  {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchMedicineComponent } from './search-medicine/search-medicine.component';
import { FetchMedicineComponent } from './fetch-medicine/fetch-medicine.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchMedicineComponent,
    FetchMedicineComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
