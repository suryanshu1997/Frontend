import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-fetch-medicine',
  templateUrl: './fetch-medicine.component.html',
  styleUrls: ['./fetch-medicine.component.css']
})
export class FetchMedicineComponent implements OnInit {

  @Input() medicineName: string;
  @Output() mediQuantity : EventEmitter<string> = new EventEmitter<string>();
  list = new Map<string, string>();


  constructor() {
    this.list.set('crocin','45');
    this.list.set('seradon','100');
    this.list.set('norflox','150');
   }

  ngOnInit() {
  }
  send()
  {
      console.log("Send fired");
    if(this.list.get(this.medicineName))
    {
      this.mediQuantity.emit(this.list.get(this.medicineName));
    }
    else{
      this.mediQuantity.emit("Invalid Entry");
    }
  

  }

}
