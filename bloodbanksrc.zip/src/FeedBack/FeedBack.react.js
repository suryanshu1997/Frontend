import React from 'react';



const FeedBack = (props) => {

    return (
        <div >
             <button id ="likeButton" className ='fa fa-thumbs-up' onClick={props.action1}></button>
             <button id ="likeButton" className ='fa fa-thumbs-down' onClick={props.action2}></button>
        </div>
    );

}

export default FeedBack;