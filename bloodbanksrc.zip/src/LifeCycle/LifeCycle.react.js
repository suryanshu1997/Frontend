import React from 'react';
import ReactDOM from 'react-dom';
import ShowCity from '../ShowCity/ShowCity.react';



class LifeCycle extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
            name : 'Suresh',
            city : "chennai"
        }
        console.log("Constructor Called  *****");
    }
    componentDidMount()
    {   
        const element = ReactDOM.findDOMNode(this);
    }
    change=()=>{
        console.log('change fired');
        this.setState({name:this.state.name+'ji'});
        this.setState({city: this.state.city="Bangalore"});
      
    }
    shouldComponentUpdate()
    {
        return true;
    }

    componentDidUpdate()
    {
        
        console.log('Did update Callled');
    }

    render() {
        console.log("Render called ####");
    
        return (
            <div id ='division'>
                   <h2> {this.state.name}</h2>
                   <button onClick ={this.change}>Update</button>
                   <ShowCity city={this.state.city}></ShowCity>
            </div>
        );
    }
}

export default LifeCycle;