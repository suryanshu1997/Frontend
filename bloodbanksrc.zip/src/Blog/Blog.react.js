import React from 'react';
import FeedBack from '../FeedBack/FeedBack.react';



class Blog extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
            likeCount:1,
            unlikeCount:1
        }
    }
    incrementLikes = ()=>
    {
        this.setState({likeCount:this.state.likeCount+1});
    }
    incrementDisLikes=()=>
    {
        this.setState({unlikeCount:this.state.unlikeCount+1});
    }

    render() {
        console.log('render Called');
        return (
            <div >
                <article>
                    <h1>Raise hands if you have donated your blood
                    </h1>

                </article>
                <p><span >Likes :</span>{this.state.likeCount}</p>
                <p><span >DisLikes :</span>{this.state.unlikeCount}</p>
               <FeedBack action1 ={this.incrementLikes} action2={this.incrementDisLikes}></FeedBack>
            </div>
        );
    }
}

export default Blog;