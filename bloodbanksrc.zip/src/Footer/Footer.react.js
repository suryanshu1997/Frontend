import React from 'react';
import Header from '../Header/Header.react';



const Footer = () => {

    return (
        <div>
            <div className="container"  >
            <div className="row">
                <div className ='col-sm-6'>
                    <h6 >Alankar Hospital</h6>
                    </div>
                <div className="col-sm-6">
                <a href='https://www.facebook.com/pages/Alankar-Hospital/189892821711625'> <span className='fa fa-facebook-official fa-2x'></span></a>
                  </div>
                  </div>
            <div className='row'>
                    <div className ='col-sm-6'>
                        <h6>Kamakshi Hospital</h6>
                        </div>
                        <div className="col-sm-6">
                        <a href='https://www.facebook.com/pages/Dr-Kamakshi-Hospital-Pallikaranai/1419280174960251'> <span className='fa fa-facebook-official fa-2x'></span></a>
                             </div>
            </div>
            <div className='row'>
                    <div className ='col-sm-6'>
                        <h6>Jagdish Hospital</h6>
                        </div>
                        <div className="col-sm-6">
                        <a href='https://www.facebook.com/'> <span className='fa fa-facebook-official fa-2x'></span></a>
                             </div>
            </div>
        </div>
        </div>
        
    );

}

export default Footer;