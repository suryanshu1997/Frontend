import React from 'react';



const ShowCity = (props) => {
        console.log("Show city called");
    return (
        
        <div >
            <h3>{props.city}</h3>
        </div>
    );

}

export default ShowCity;