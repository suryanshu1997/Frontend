import React from 'react';
import logo from './logo.svg';
import Header from './Header/Header.react';
import './App.css';
import Footer from './Footer/Footer.react';
import Content from './Content/Content.react';
import Navigation from './Navigation/Navigation.react';

import blood from './blood.jpg'



function App() {
  return (
    <div className="App">
      
      <Header>

      </Header>
      <Navigation>
        
      </Navigation>
      
    </div>
  );
}

export default App;
