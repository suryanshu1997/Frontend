import React from 'react';
import DataGrid from '../DataGrid/DataGrid.react';
import PropTypes from 'prop-types';

let donorName= "Ramesh";
let donorList = [ 
    {donorName:"Ramesh", phoneNumber:9924221, bloodGroup:'opos', donationCount:43},
    {donorName:"Suresh", phoneNumber:99422211, bloodGroup:'abneg', donationCount:43},
    {donorName:"Ganesh", phoneNumber:99760121, bloodGroup:'opneg', donationCount:43}
];
const ShowDonor = (props) => {

    return (
        
        <div >
            <h1 className='text-center'>{props.title}</h1>
                <DataGrid donorList={donorList}>

                    <thead>
                        <tr>
                            <th>Donor Name</th>
                            <th>Phone Number</th>
                            <th>Blood Group</th>
                        </tr>
                    </thead>
                </DataGrid>
        </div>
    );

}

ShowDonor.propTypes={
    title : PropTypes.string.isRequired
};

export default ShowDonor;