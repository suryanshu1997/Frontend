import React from 'react';
import { Z_BUF_ERROR } from 'zlib';

const clear = (msg)=>{
    console.log('clear invoked');
     return () =>{
         console.log("Inner function called"+msg)
     }
}

const Search = () => {

    return (
        <div >
            <button className='fa fa-search' onClick={(event)=>{console.log(event)}}>Search</button>
            <button className ='fa fa-crosshairs' onClick ={clear('Ramesh')}>Clear</button>
        </div>
    );

}

export default Search;