export interface Credential {
    userName: string;
    passWord: string;
}
