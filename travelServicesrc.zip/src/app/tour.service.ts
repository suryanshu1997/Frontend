import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TourInterface } from './tour-interface';

@Injectable({
  providedIn: 'root'
})
export class TourService {

  constructor(private http: HttpClient) { }


  findAll(): Observable< TourInterface[] >
  {
     return this.http.get<TourInterface[]>("http://localhost:3000/tours");
  }
}
