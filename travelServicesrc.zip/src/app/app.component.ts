import { Component } from '@angular/core';
import { NavigationLinks } from './navigation-links';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Suryanshu travelService';
  subHeading ='Chennai';

  // links = ['Home', 'Catalog', 'Payment','Contact'];
  links : NavigationLinks[] = [
  {text:'Home',link:'/search'},
  {text:'Catalog',link:'/show'},
  ];
}
