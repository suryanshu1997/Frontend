export interface NavigationLinks {
    link:string;
    text:string;
}
