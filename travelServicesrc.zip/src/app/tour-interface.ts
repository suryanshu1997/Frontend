export interface TourInterface {
    id:number;
    tourName:string;
    price: number;
}
