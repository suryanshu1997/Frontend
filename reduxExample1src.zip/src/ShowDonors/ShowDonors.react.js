import React from 'react';
import {connect} from 'react-redux';
import {myactionCreator, getListByThunk} from '../donorReducer'


const ShowDonors =(props) => {
        if(!props.isLoaded)
        {
            return(
            
                <div>
                <h2>Loading</h2>
                <button onClick={props.get}>Get Data</button>
                </div>
            );
        }
        else{
            return(
            props.list.map(eachValue=>{
                return(
                        <div>
                            <p>{eachValue.id}</p>
                            <p>{eachValue.donorName}</p>
                            <p>{eachValue.bloodGroup}</p>
                            <p>{eachValue.phoneNumber}</p>
                            <p>{eachValue.lastDonated}</p>
                        </div>
                    )
            })

            
            )

            
        }
        

}

const mapStateToProps = (state) => {
    return {
        list : state.payload,
        isLoaded: state.isLoaded
    }
}
 const mapDispatchToProps = (dispatch) => {
    return {
        get: () => {
            dispatch(getListByThunk())
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(ShowDonors);