import React from 'react';
import './App.css';
import Greeter from './Greeter/Greeter.react';
import ShowDonors from './ShowDonors/ShowDonors.react'

function App() {
  return (
    <div>
   <Greeter></Greeter>
   
   <ShowDonors></ShowDonors>
   </div>
  
   
  );
}

export default App;
