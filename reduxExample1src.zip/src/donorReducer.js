import axios from 'axios';
import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

const initialState = {
    isloaded:false,
    list:[{}]
}
export const myactionCreator =(list, status)=>{
    return {
        type: 'GET_ALL_DONORS',
        payload: list,
        isLoaded: status

    }
}
export function getListByThunk(){
    return function(dispatch)
    {
            axios.get("http://localhost:3009/bloodDonors")
            .then(resp=>dispatch(myactionCreator(resp.data,true)));
    }

}
export const donorReducer = (state =initialState, action) => {
    switch (action.type) {
        case 'GET_ALL_DONORS':
            return Object.assign({},action);
        default:
            return state
    }
}

let restStore = createStore(donorReducer, applyMiddleware(thunk));
export default restStore;