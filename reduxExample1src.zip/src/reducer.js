 const reducer = (state = {
    message: "Hello"
}, action) => {
    switch (action.type) {
        case 'BIRTHDAY':
            console.log(Object.assign({},action));
            return Object.assign({}, action);
        case 'VALENTINEDAY':
            return {...action};
        default:
            return state
    }
}
export default reducer;