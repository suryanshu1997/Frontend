import reducer from './reducer';
import {createStore} from 'redux';

export const login ={
    type: "LOGOUT",
    title: "Login" 
}
export const logout ={
    type: "LOGIN",
    title: "Logout"
}
const store = createStore(reducer);
export default store;