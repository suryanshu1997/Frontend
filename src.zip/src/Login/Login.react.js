import React from 'react';
import {connect} from 'react-redux'



const Login = (props) => {

    return (
        <div >
            <button onClick={props.action}>{props.msg}</button>
        </div>
    );

}
const mapStateToProps = (state) => {
    return {
        msg: state.title
    }
}
export default  connect(mapStateToProps)(Login)
